﻿installation method:

1. Copy the Newton folder to the plug-in directory of the AE software, such as:
  ….\Adobe After Effects CC\Support Files\Plug-ins

2. Open the AE software, create a new layer, and then open Newton 4 in the top menu [Composite] to use it.